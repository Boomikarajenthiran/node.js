// ==========================================================================
// Application Core Controller - "How Will IT Change in the Next 3 Years?"
// ==========================================================================

class AppController {
  constructor() {
    this.currentLang = localStorage.getItem('it_future_lang') || 'en';
    this.activeCareerFilter = 'all';
    this.activeSkillFilter = 'all';
    this.activeRoadmapDuration = '30_days';
    
    // Quiz state
    this.currentQuizStep = 0;
    this.quizAnswers = {};
    this.quizResult = null;

    // Roadmap milestone completion state from localStorage
    this.completedMilestones = JSON.parse(localStorage.getItem('it_future_milestones') || '{}');

    this.init();
  }

  init() {
    this.setupLanguage();
    this.initCanvasBackground();
    this.renderTransformationCards();
    this.renderCareers();
    this.renderSkills();
    this.renderQuizStep();
    this.renderRoadmaps();
    this.setupEventListeners();
    this.setupScrollSpy();
    
    // Initialize icons
    if (window.lucide) {
      window.lucide.createIcons();
    }
  }

  // --- Translation & Internationalization ---
  t(key) {
    const langDict = TRANSLATIONS[this.currentLang] || TRANSLATIONS.en;
    return langDict[key] || TRANSLATIONS.en[key] || key;
  }

  setupLanguage() {
    document.body.className = `lang-${this.currentLang}`;
    this.updateStaticTranslations();
  }

  toggleLanguage() {
    this.currentLang = this.currentLang === 'en' ? 'ta' : 'en';
    localStorage.setItem('it_future_lang', this.currentLang);
    this.setupLanguage();
    
    // Re-render dynamic components with new translations
    this.renderTransformationCards();
    this.renderCareers();
    this.renderSkills();
    this.renderRoadmaps();

    if (this.quizResult) {
      this.showQuizResult(this.quizResult);
    } else {
      this.renderQuizStep();
    }

    if (window.lucide) {
      window.lucide.createIcons();
    }
  }

  updateStaticTranslations() {
    document.querySelectorAll('[data-i18n]').forEach(el => {
      const key = el.getAttribute('data-i18n');
      if (key) {
        el.textContent = this.t(key);
      }
    });

    // Update html lang attribute
    document.documentElement.lang = this.currentLang;
  }

  // --- Particle Network Canvas Background ---
  initCanvasBackground() {
    const canvas = document.getElementById('bg-canvas');
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    let width = canvas.width = window.innerWidth;
    let height = canvas.height = window.innerHeight;

    window.addEventListener('resize', () => {
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    });

    const particles = [];
    const particleCount = Math.min(Math.floor(window.innerWidth / 22), 65);

    for (let i = 0; i < particleCount; i++) {
      particles.push({
        x: Math.random() * width,
        y: Math.random() * height,
        vx: (Math.random() - 0.5) * 0.45,
        vy: (Math.random() - 0.5) * 0.45,
        radius: Math.random() * 1.8 + 0.8,
        color: Math.random() > 0.5 ? '#8B5CF6' : '#06B6D4'
      });
    }

    function animate() {
      ctx.clearRect(0, 0, width, height);

      // Connect nearby particles
      for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
          const dx = particles[i].x - particles[j].x;
          const dy = particles[i].y - particles[j].y;
          const dist = Math.sqrt(dx * dx + dy * dy);

          if (dist < 130) {
            ctx.beginPath();
            ctx.strokeStyle = `rgba(139, 92, 246, ${0.15 * (1 - dist / 130)})`;
            ctx.lineWidth = 0.75;
            ctx.moveTo(particles[i].x, particles[i].y);
            ctx.lineTo(particles[j].x, particles[j].y);
            ctx.stroke();
          }
        }
      }

      // Draw & update particles
      particles.forEach(p => {
        p.x += p.vx;
        p.y += p.vy;

        if (p.x < 0) p.x = width;
        if (p.x > width) p.x = 0;
        if (p.y < 0) p.y = height;
        if (p.y > height) p.y = 0;

        ctx.beginPath();
        ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
        ctx.fillStyle = p.color;
        ctx.shadowBlur = 8;
        ctx.shadowColor = p.color;
        ctx.fill();
        ctx.shadowBlur = 0;
      });

      requestAnimationFrame(animate);
    }

    animate();
  }

  // --- Section 2: Transformation Cards ---
  renderTransformationCards() {
    const container = document.getElementById('transformation-cards-container');
    if (!container) return;

    container.innerHTML = DATA.transformationPoints.map((item, index) => `
      <div class="glass-card trans-card ${item.badgeType}">
        <div class="trans-header">
          <div class="trans-icon-box">
            <i data-lucide="${item.icon}" class="w-6 h-6"></i>
          </div>
          <span class="trans-tag">${this.t(item.tagKey)}</span>
        </div>
        <h3 class="trans-title">${this.t(item.titleKey)}</h3>
        <p class="trans-desc">${this.t(item.descKey)}</p>
      </div>
    `).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  // --- Section 3: Alternative Careers ---
  renderCareers() {
    const container = document.getElementById('careers-grid-container');
    if (!container) return;

    const filtered = DATA.careers.filter(c => {
      if (this.activeCareerFilter === 'all') return true;
      return c.category === this.activeCareerFilter;
    });

    container.innerHTML = filtered.map(career => `
      <div class="glass-card career-card">
        <div>
          <div class="career-icon-wrapper">
            <i data-lucide="${career.icon}" class="w-6 h-6"></i>
          </div>
          <h3 class="career-title">${this.t(career.titleKey)}</h3>
          <p class="career-desc">${this.t(career.descKey)}</p>
        </div>
        <button class="btn-card-action" onclick="app.openCareerModal('${career.id}')">
          <i data-lucide="sparkles" class="w-4 h-4"></i>
          <span>${this.t('btn_skills_needed')}</span>
        </button>
      </div>
    `).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  openCareerModal(careerId) {
    const career = DATA.careers.find(c => c.id === careerId);
    if (!career) return;

    const modal = document.getElementById('career-modal');
    const content = document.getElementById('career-modal-content');

    content.innerHTML = `
      <div style="display: flex; align-items: center; gap: 1rem; margin-bottom: 1.25rem;">
        <div class="brand-icon-wrapper" style="width: 50px; height: 50px;">
          <i data-lucide="${career.icon}" class="w-6 h-6 text-white"></i>
        </div>
        <div>
          <h3 style="font-size: 1.35rem; font-weight: 800; color: #fff;">${this.t(career.titleKey)}</h3>
          <span style="font-size: 0.8rem; color: #38BDF8; font-weight: 600;">${career.category.toUpperCase()} SECTOR</span>
        </div>
      </div>

      <p style="font-size: 0.95rem; color: #CBD5E1; margin-bottom: 1.5rem; line-height: 1.6;">
        ${this.t(career.descKey)}
      </p>

      <!-- Quick Metrics -->
      <div style="display: grid; grid-template-columns: repeat(3, 1fr); gap: 0.75rem; margin-bottom: 1.5rem;">
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 0.75rem; text-align: center;">
          <div style="font-size: 0.74rem; color: var(--text-muted);">${this.t('modal_demand')}</div>
          <div style="font-size: 0.98rem; font-weight: 700; color: #34D399;">${career.demandLevel}</div>
        </div>
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 0.75rem; text-align: center;">
          <div style="font-size: 0.74rem; color: var(--text-muted);">${this.t('modal_time')}</div>
          <div style="font-size: 0.98rem; font-weight: 700; color: #38BDF8;">${career.timeToTransition}</div>
        </div>
        <div style="background: rgba(255,255,255,0.03); border: 1px solid rgba(255,255,255,0.08); border-radius: 10px; padding: 0.75rem; text-align: center;">
          <div style="font-size: 0.74rem; color: var(--text-muted);">${this.t('modal_salary')}</div>
          <div style="font-size: 0.98rem; font-weight: 700; color: #F472B6;">${career.avgSalaryGrowth}</div>
        </div>
      </div>

      <!-- Skills To Master -->
      <div style="margin-bottom: 1.5rem;">
        <h4 style="font-size: 0.95rem; font-weight: 700; color: #fff; margin-bottom: 0.65rem;">${this.t('modal_primary_skills')}</h4>
        <div style="display: flex; flex-wrap: wrap; gap: 0.5rem;">
          ${career.primarySkills.map(s => `
            <span style="background: rgba(139, 92, 246, 0.15); border: 1px solid rgba(139, 92, 246, 0.35); color: #C084FC; padding: 4px 10px; border-radius: 8px; font-size: 0.84rem; font-weight: 600;">
              ${s}
            </span>
          `).join('')}
        </div>
      </div>

      <!-- Strategy Callout -->
      <div style="background: rgba(6, 182, 212, 0.1); border-left: 3px solid #06B6D4; border-radius: 8px; padding: 0.95rem 1.15rem; margin-bottom: 1.75rem;">
        <div style="font-size: 0.8rem; font-weight: 700; color: #38BDF8; text-transform: uppercase; margin-bottom: 0.25rem;">${this.t('modal_tips_title')}</div>
        <div style="font-size: 0.9rem; color: #E2E8F0; line-height: 1.55;">${career.transitionTips}</div>
      </div>

      <div style="display: flex; justify-content: flex-end; gap: 0.75rem;">
        <button class="btn-glow-secondary" style="padding: 0.65rem 1.35rem; font-size: 0.9rem;" onclick="app.closeModals()">
          ${this.t('modal_close')}
        </button>
        <a href="#roadmaps" class="btn-glow-primary" style="padding: 0.65rem 1.35rem; font-size: 0.9rem;" onclick="app.closeModals()">
          ${this.t('btn_start_learning')}
        </a>
      </div>
    `;

    document.body.style.overflow = 'hidden';
    modal.classList.add('active');
    if (window.lucide) window.lucide.createIcons();
  }

  // --- Section 4: Skills Needed ---
  renderSkills() {
    const container = document.getElementById('skills-grid-container');
    if (!container) return;

    const filtered = DATA.skills.filter(s => {
      if (this.activeSkillFilter === 'all') return true;
      return s.category === this.activeSkillFilter;
    });

    container.innerHTML = filtered.map(skill => `
      <div class="glass-card skill-card">
        <div class="skill-header">
          <div class="skill-icon-box">
            <i data-lucide="${skill.icon}" class="w-5 h-5"></i>
          </div>
          <span class="skill-level-badge">${this.t(skill.levelKey)}</span>
        </div>

        <h3 class="skill-title">${this.t(skill.titleKey)}</h3>
        <p class="skill-desc">${this.t(skill.descKey)}</p>

        <div class="skill-meter-wrap">
          <div class="skill-meter-label">
            <span>${this.t('skill_card_importance')}</span>
            <span>${skill.importance}%</span>
          </div>
          <div class="skill-meter-bar">
            <div class="skill-meter-fill" style="width: ${skill.importance}%;"></div>
          </div>
        </div>

        <div>
          <div style="font-size: 0.76rem; color: var(--text-muted); margin-bottom: 0.45rem; font-weight: 600;">
            ${this.t('skill_card_keytools')}
          </div>
          <div class="skill-tools-list">
            ${skill.keyTools.map(t => `<span class="tool-chip">${t}</span>`).join('')}
          </div>
        </div>
      </div>
    `).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  // --- Section 5: Quiz Engine ---
  renderQuizStep() {
    const qIndex = this.currentQuizStep;
    const questions = DATA.quizQuestions;
    const qData = questions[qIndex];

    const stepLabel = document.getElementById('quiz-step-label');
    const qTitle = document.getElementById('quiz-question-title');
    const optionsContainer = document.getElementById('quiz-options-container');
    const prevBtn = document.getElementById('btn-quiz-prev');
    const nextBtn = document.getElementById('btn-quiz-next');
    const nextLabel = document.getElementById('quiz-next-label');
    const progressFill = document.getElementById('quiz-progress-fill');

    if (!stepLabel || !qData) return;

    stepLabel.textContent = `${this.t('quiz_step')} ${qIndex + 1} ${this.t('quiz_of')} ${questions.length}`;
    qTitle.textContent = this.t(qData.questionKey);
    progressFill.style.width = `${((qIndex + 1) / questions.length) * 100}%`;

    // Render options
    optionsContainer.innerHTML = qData.options.map((opt, i) => {
      const isSelected = this.quizAnswers[qData.id] && this.quizAnswers[qData.id].value === opt.value;
      return `
        <button class="quiz-opt-btn ${isSelected ? 'selected' : ''}" onclick="app.selectQuizOption('${qData.id}', ${i})">
          <div class="opt-indicator"></div>
          <span>${this.t(opt.labelKey)}</span>
        </button>
      `;
    }).join('');

    // Update buttons
    prevBtn.style.visibility = qIndex > 0 ? 'visible' : 'hidden';
    
    const hasSelection = !!this.quizAnswers[qData.id];
    nextBtn.disabled = !hasSelection;
    nextBtn.style.opacity = hasSelection ? '1' : '0.5';
    nextBtn.style.cursor = hasSelection ? 'pointer' : 'not-allowed';

    if (qIndex === questions.length - 1) {
      nextLabel.textContent = this.t('quiz_calculate');
    } else {
      nextLabel.textContent = this.t('quiz_next');
    }
  }

  selectQuizOption(questionId, optionIndex) {
    const qData = DATA.quizQuestions.find(q => q.id === questionId);
    if (!qData) return;

    const selectedOption = qData.options[optionIndex];
    this.quizAnswers[questionId] = selectedOption;
    this.renderQuizStep();
  }

  nextQuizStep() {
    if (this.currentQuizStep < DATA.quizQuestions.length - 1) {
      this.currentQuizStep++;
      this.renderQuizStep();
    } else {
      this.evaluateQuizResult();
    }
  }

  prevQuizStep() {
    if (this.currentQuizStep > 0) {
      this.currentQuizStep--;
      this.renderQuizStep();
    }
  }

  evaluateQuizResult() {
    let score = 0;
    const ans = this.quizAnswers;

    if (ans.role && ans.role.score) score += ans.role.score;
    if (ans.ai_usage && ans.ai_usage.score) score += ans.ai_usage.score;
    if (ans.skill_level && ans.skill_level.score) score += ans.skill_level.score;

    let resultType = 'change';
    if (score >= 7) {
      resultType = 'assist';
    } else if (score <= 4) {
      resultType = 'quick';
    } else {
      resultType = 'change';
    }

    this.quizResult = resultType;
    this.showQuizResult(resultType);
  }

  showQuizResult(type) {
    const stepView = document.getElementById('quiz-step-view');
    const resultView = document.getElementById('quiz-result-view');
    if (!stepView || !resultView) return;

    stepView.style.display = 'none';
    resultView.style.display = 'block';

    let titleKey, badgeKey, descKey, actionKey, badgeClass;

    if (type === 'assist') {
      titleKey = 'quiz_res1_title';
      badgeKey = 'quiz_res1_badge';
      descKey = 'quiz_res1_desc';
      actionKey = 'quiz_res1_action';
      badgeClass = 'assist';
    } else if (type === 'change') {
      titleKey = 'quiz_res2_title';
      badgeKey = 'quiz_res2_badge';
      descKey = 'quiz_res2_desc';
      actionKey = 'quiz_res2_action';
      badgeClass = 'change';
    } else {
      titleKey = 'quiz_res3_title';
      badgeKey = 'quiz_res3_badge';
      descKey = 'quiz_res3_desc';
      actionKey = 'quiz_res3_action';
      badgeClass = 'quick';
    }

    // Recommendation based on Interest
    let recommendationHtml = '';
    const interestVal = this.quizAnswers.interest ? this.quizAnswers.interest.value : 'ai_ml';
    
    let pathTitle = 'AI & Data Science Pathway (30 or 90 Days)';
    let pathDesc = 'Master Python, Prompt Engineering, SQL, and Capstone Building to stand out.';
    
    if (interestVal === 'security_cloud') {
      pathTitle = 'Cybersecurity & Cloud Defense Track';
      pathDesc = 'Focus on Linux, AWS/Azure infrastructure, and security posture to secure enterprise workflows.';
    } else if (interestVal === 'design_product') {
      pathTitle = 'Product & UI/UX Design Track';
      pathDesc = 'Combine human empathy, design systems, and AI prototyping to build modern user experiences.';
    } else if (interestVal === 'biz_freelance') {
      pathTitle = 'Digital Growth & Freelancing Track';
      pathDesc = 'Leverage AI workflows to deliver end-to-end solutions 5x faster for global clients.';
    }

    recommendationHtml = `
      <div class="result-recommendation-box">
        <div style="display: flex; align-items: center; gap: 0.5rem; color: #38BDF8; font-weight: 700; font-size: 0.88rem; margin-bottom: 0.35rem;">
          <i data-lucide="compass" class="w-4 h-4"></i>
          <span>${this.t('quiz_recommended_path')}</span>
        </div>
        <div style="font-weight: 700; color: #fff; font-size: 1.05rem; margin-bottom: 0.25rem;">${pathTitle}</div>
        <div style="font-size: 0.88rem; color: #CBD5E1;">${pathDesc}</div>
      </div>
    `;

    resultView.innerHTML = `
      <div class="result-badge ${badgeClass}">
        ${this.t(badgeKey)}
      </div>
      <h3 class="result-title">${this.t(titleKey)}</h3>
      <p class="result-desc">${this.t(descKey)}</p>

      <div class="result-action-callout">
        ${this.t(actionKey)}
      </div>

      ${recommendationHtml}

      <div style="display: flex; justify-content: center; gap: 1rem; flex-wrap: wrap;">
        <button class="btn-glow-secondary" onclick="app.retakeQuiz()">
          <i data-lucide="rotate-ccw" class="w-4 h-4"></i>
          <span>${this.t('quiz_retake')}</span>
        </button>
        <a href="#roadmaps" class="btn-glow-primary">
          <i data-lucide="milestone" class="w-4 h-4"></i>
          <span>${this.t('btn_start_learning')}</span>
        </a>
      </div>
    `;

    if (window.lucide) window.lucide.createIcons();
  }

  retakeQuiz() {
    this.currentQuizStep = 0;
    this.quizAnswers = {};
    this.quizResult = null;
    document.getElementById('quiz-step-view').style.display = 'block';
    document.getElementById('quiz-result-view').style.display = 'none';
    this.renderQuizStep();
  }

  // --- Section 6: Roadmaps & Progress Tracking ---
  renderRoadmaps() {
    const container = document.getElementById('roadmap-tracks-container');
    if (!container) return;

    const duration = this.activeRoadmapDuration;
    const roadmapSet = DATA.roadmaps[duration];
    if (!roadmapSet) return;

    const tracks = [
      { key: 'ai_data', icon: 'sparkles', data: roadmapSet.ai_data },
      { key: 'cybersecurity', icon: 'shield-alert', data: roadmapSet.cybersecurity },
      { key: 'cloud', icon: 'cloud-lightning', data: roadmapSet.cloud }
    ];

    container.innerHTML = tracks.map(track => {
      const stepCount = track.data.steps.length;
      let completedCount = 0;
      
      track.data.steps.forEach((_, idx) => {
        const milestoneId = `${duration}_${track.key}_${idx}`;
        if (this.completedMilestones[milestoneId]) completedCount++;
      });

      const percentage = Math.round((completedCount / stepCount) * 100);

      return `
        <div class="glass-card roadmap-card">
          <div class="track-header">
            <div style="display: flex; align-items: center; gap: 0.65rem; margin-bottom: 0.5rem;">
              <div class="trans-icon-box" style="width: 38px; height: 38px; border-radius: 10px;">
                <i data-lucide="${track.icon}" class="w-4 h-4 text-purple-400"></i>
              </div>
              <h3 class="track-title">${this.t(track.data.titleKey)}</h3>
            </div>
            <div class="track-subtitle">${this.t(track.data.subtitleKey)}</div>
          </div>

          <div class="roadmap-progress-box">
            <div style="display: flex; justify-content: space-between; font-size: 0.8rem; font-weight: 700; color: #CBD5E1; margin-bottom: 0.35rem;">
              <span>${this.t('roadmap_progress')} ${completedCount}/${stepCount}</span>
              <span style="color: #38BDF8;">${percentage}%</span>
            </div>
            <div class="skill-meter-bar">
              <div class="skill-meter-fill" style="width: ${percentage}%;"></div>
            </div>
          </div>

          <div class="timeline-flow">
            ${track.data.steps.map((step, idx) => {
              const milestoneId = `${duration}_${track.key}_${idx}`;
              const isDone = !!this.completedMilestones[milestoneId];
              return `
                <div class="timeline-item" onclick="app.toggleMilestone('${milestoneId}')">
                  <div class="timeline-node ${isDone ? 'completed' : ''}" 
                       title="Click to toggle milestone status">
                    ${isDone ? '✓' : (idx + 1)}
                  </div>
                  <div class="timeline-content" style="${isDone ? 'border-color: rgba(16, 185, 129, 0.35); background: rgba(16, 185, 129, 0.05);' : ''}">
                    <div class="step-day">${this.t(step.dayKey)}</div>
                    <div class="step-name">${this.t(step.titleKey)}</div>
                    <div class="step-desc">${this.t(step.descKey)}</div>
                  </div>
                </div>
              `;
            }).join('')}
          </div>

          <button class="btn-card-action" onclick="app.openFuturePlannerModal('${track.key}')">
            <i data-lucide="flag" class="w-4 h-4"></i>
            <span>${this.t('btn_start_learning')}</span>
          </button>
        </div>
      `;
    }).join('');

    if (window.lucide) window.lucide.createIcons();
  }

  toggleMilestone(milestoneId) {
    if (this.completedMilestones[milestoneId]) {
      delete this.completedMilestones[milestoneId];
      this.showToast('Milestone updated!');
    } else {
      this.completedMilestones[milestoneId] = true;
      this.showToast('Milestone completed! Keep going! 🎉');
    }
    localStorage.setItem('it_future_milestones', JSON.stringify(this.completedMilestones));
    this.renderRoadmaps();
  }

  // --- Modal Controllers ---
  openFuturePlannerModal(trackKey = '') {
    const modal = document.getElementById('planner-modal');
    if (!modal) return;

    if (trackKey === 'ai_data') {
      document.getElementById('plan-select-role').value = 'AI & Machine Learning Engineer';
    } else if (trackKey === 'cybersecurity') {
      document.getElementById('plan-select-role').value = 'Cybersecurity Defense Specialist';
    } else if (trackKey === 'cloud') {
      document.getElementById('plan-select-role').value = 'Cloud Architect & DevOps';
    }

    document.body.style.overflow = 'hidden';
    modal.classList.add('active');
    if (window.lucide) window.lucide.createIcons();
  }

  closeModals() {
    document.querySelectorAll('.modal-overlay').forEach(m => m.classList.remove('active'));
    document.body.style.overflow = '';
  }

  savePlanLocally() {
    const name = document.getElementById('plan-input-name').value || 'Learner';
    const role = document.getElementById('plan-select-role').value;
    const timeframe = document.getElementById('plan-select-timeframe').value;

    const plan = { name, role, timeframe, savedAt: new Date().toISOString() };
    localStorage.setItem('it_future_user_plan', JSON.stringify(plan));
    this.showToast(this.t('saved_alert'));
  }

  printPlan() {
    window.print();
  }

  // Toast Notification
  showToast(message) {
    let toast = document.getElementById('app-toast');
    if (!toast) {
      toast = document.createElement('div');
      toast.id = 'app-toast';
      toast.className = 'toast-notification';
      toast.innerHTML = `<i data-lucide="check-circle" class="w-5 h-5 text-emerald-400"></i><span id="toast-text"></span>`;
      document.body.appendChild(toast);
      if (window.lucide) window.lucide.createIcons();
    }

    const toastText = document.getElementById('toast-text');
    if (toastText) toastText.textContent = message;

    toast.classList.add('show');
    clearTimeout(this._toastTimeout);
    this._toastTimeout = setTimeout(() => {
      toast.classList.remove('show');
    }, 3200);
  }

  // --- Event Listeners & UI Binding ---
  setupEventListeners() {
    // Language Toggle
    const langBtn = document.getElementById('lang-toggle-btn');
    if (langBtn) {
      langBtn.addEventListener('click', () => this.toggleLanguage());
    }

    // Mobile Menu Toggle
    const mobileMenuBtn = document.getElementById('mobile-menu-btn');
    const navLinks = document.getElementById('nav-links');
    if (mobileMenuBtn && navLinks) {
      mobileMenuBtn.addEventListener('click', () => {
        const isOpen = navLinks.classList.toggle('mobile-open');
        mobileMenuBtn.innerHTML = isOpen ? `<i data-lucide="x" class="w-6 h-6"></i>` : `<i data-lucide="menu" class="w-6 h-6"></i>`;
        if (window.lucide) window.lucide.createIcons();
      });

      navLinks.querySelectorAll('a').forEach(a => {
        a.addEventListener('click', () => {
          navLinks.classList.remove('mobile-open');
          mobileMenuBtn.innerHTML = `<i data-lucide="menu" class="w-6 h-6"></i>`;
          if (window.lucide) window.lucide.createIcons();
        });
      });
    }

    // Career Filter Buttons
    document.querySelectorAll('#career-filters .filter-pill').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('#career-filters .filter-pill').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.activeCareerFilter = e.target.getAttribute('data-filter');
        this.renderCareers();
      });
    });

    // Skill Filter Buttons
    document.querySelectorAll('#skill-filters .filter-pill').forEach(btn => {
      btn.addEventListener('click', (e) => {
        document.querySelectorAll('#skill-filters .filter-pill').forEach(b => b.classList.remove('active'));
        e.target.classList.add('active');
        this.activeSkillFilter = e.target.getAttribute('data-skill-filter');
        this.renderSkills();
      });
    });

    // Quiz Buttons
    const nextQuizBtn = document.getElementById('btn-quiz-next');
    const prevQuizBtn = document.getElementById('btn-quiz-prev');
    if (nextQuizBtn) nextQuizBtn.addEventListener('click', () => this.nextQuizStep());
    if (prevQuizBtn) prevQuizBtn.addEventListener('click', () => this.prevQuizStep());

    // Roadmap Tabs
    const tab30 = document.getElementById('tab-30-btn');
    const tab90 = document.getElementById('tab-90-btn');
    if (tab30 && tab90) {
      tab30.addEventListener('click', () => {
        tab30.classList.add('active');
        tab90.classList.remove('active');
        this.activeRoadmapDuration = '30_days';
        this.renderRoadmaps();
      });
      tab90.addEventListener('click', () => {
        tab90.classList.add('active');
        tab30.classList.remove('active');
        this.activeRoadmapDuration = '90_days';
        this.renderRoadmaps();
      });
    }

    // Modals
    const closeCareerBtn = document.getElementById('modal-close-career-btn');
    const closePlannerBtn = document.getElementById('modal-close-planner-btn');
    if (closeCareerBtn) closeCareerBtn.addEventListener('click', () => this.closeModals());
    if (closePlannerBtn) closePlannerBtn.addEventListener('click', () => this.closeModals());

    const openPlannerBtn = document.getElementById('btn-open-planner');
    if (openPlannerBtn) {
      openPlannerBtn.addEventListener('click', () => this.openFuturePlannerModal());
    }

    const savePlanBtn = document.getElementById('btn-save-plan-local');
    const printPlanBtn = document.getElementById('btn-print-plan-action');
    if (savePlanBtn) savePlanBtn.addEventListener('click', () => this.savePlanLocally());
    if (printPlanBtn) printPlanBtn.addEventListener('click', () => this.printPlan());

    // Close on overlay click
    document.querySelectorAll('.modal-overlay').forEach(overlay => {
      overlay.addEventListener('click', (e) => {
        if (e.target === overlay) this.closeModals();
      });
    });

    // Close on Escape key
    window.addEventListener('keydown', (e) => {
      if (e.key === 'Escape') {
        this.closeModals();
        if (navLinks) {
          navLinks.classList.remove('mobile-open');
          if (mobileMenuBtn) {
            mobileMenuBtn.innerHTML = `<i data-lucide="menu" class="w-6 h-6"></i>`;
            if (window.lucide) window.lucide.createIcons();
          }
        }
      }
    });

    // Back to top
    const backTopBtn = document.getElementById('btn-back-top');
    if (backTopBtn) {
      backTopBtn.addEventListener('click', () => {
        window.scrollTo({ top: 0, behavior: 'smooth' });
      });
    }
  }

  // --- Scroll Spy for Navbar ---
  setupScrollSpy() {
    const sections = document.querySelectorAll('section[id]');
    const navLinks = document.querySelectorAll('.nav-link');

    const observer = new IntersectionObserver((entries) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const id = entry.target.getAttribute('id');
          navLinks.forEach(link => {
            link.classList.remove('active');
            if (link.getAttribute('href') === `#${id}`) {
              link.classList.add('active');
            }
          });
        }
      });
    }, {
      threshold: 0.25,
      rootMargin: "-70px 0px -40% 0px"
    });

    sections.forEach(s => observer.observe(s));
  }
}

// Instantiate global app instance
const app = new AppController();
