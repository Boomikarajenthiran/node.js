// Complete English and Tamil Translation Dictionary

const TRANSLATIONS = {
  en: {
    // Nav
    nav_brand: "IT 2029 Vision",
    nav_home: "Home",
    nav_after3yrs: "IT After 3 Years",
    nav_careers: "Alternative Careers",
    nav_skills: "Skills Needed",
    nav_quiz: "AI Quiz",
    nav_roadmaps: "Roadmaps",
    nav_future_plan: "My Future Plan",
    nav_lang_toggle: "தமிழ் (Tamil)",

    // Hero Section
    hero_badge: "2026 – 2029 Industry Outlook",
    hero_title: "How Will IT Change in the Next 3 Years?",
    hero_subtitle: "IT will not disappear. It will transform with AI.",
    hero_desc: "Learn future IT skills, explore alternative careers, and prepare for the AI-powered workplace.",
    hero_btn_explore: "Explore Careers",
    hero_btn_quiz: "Take AI Quiz",
    hero_btn_roadmap: "View Roadmaps",
    hero_stat1_num: "80%",
    hero_stat1_label: "Routine Coding & Testing Assisted by AI",
    hero_stat2_num: "97M+",
    hero_stat2_label: "New Specialized Tech & AI Roles Worldwide",
    hero_stat3_num: "100%",
    hero_stat3_label: "Rise in Demand for Human Power Skills",

    // Section 2: IT After 3 Years
    sec2_badge: "Future Outlook",
    sec2_title: "IT After 3 Years: What Will Really Happen?",
    sec2_subtitle: "Understanding the shift from manual routine tasks to intelligent, AI-augmented engineering.",

    trans_card1_tag: "Automation Shift",
    trans_card1_title: "AI Automates Repetitive Work",
    trans_card1_desc: "AI may automate basic coding, unit testing, repetitive data entry, boilerplate documentation, and level-1 customer support.",

    trans_card2_tag: "Team Structure",
    trans_card2_title: "Leaner Teams for Routine Tasks",
    trans_card2_desc: "Companies may need fewer employees for manual, repetitive tasks as AI agents handle routine workflows 10x faster.",

    trans_card3_tag: "Core Reality",
    trans_card3_title: "IT Will Not Disappear; It Will Change",
    trans_card3_desc: "The IT industry is not dying—it is upgrading. Software systems will become more complex, requiring architects, orchestrators, and AI supervisors.",

    trans_card4_tag: "Booming Sectors",
    trans_card4_title: "Explosive Growth in Next-Gen Tech",
    trans_card4_desc: "New job opportunities will grow rapidly in AI, cloud computing, cybersecurity, data analysis, robotics, and digital enterprise services.",

    trans_card5_tag: "Human Edge",
    trans_card5_title: "Human Skills Will Matter More",
    trans_card5_desc: "Creativity, strategic communication, teamwork, empathy, and first-principles problem-solving will be the ultimate career safeguards.",

    // Section 3: Alternative Careers
    sec3_badge: "Career Resilience",
    sec3_title: "If an IT Job Is Affected, What Can Employees Do?",
    sec3_subtitle: "Discover high-growth alternative careers and adjacent tech fields where your technical acumen gives you an unfair advantage.",
    filter_all: "All Careers",
    filter_tech: "Tech & Data",
    filter_creative: "Design & Creative",
    filter_business: "Business & Management",
    filter_domain: "Emerging Domains",
    btn_skills_needed: "Skills Needed & Transition Guide",
    modal_demand: "Market Demand",
    modal_time: "Time to Pivot",
    modal_salary: "Salary Growth Trend",
    modal_primary_skills: "Core Skills to Master:",
    modal_tips_title: "Transition Strategy:",
    modal_close: "Close",

    career_dm_title: "Digital Marketing & Growth",
    career_dm_desc: "Drive ROI and digital visibility using AI ad tools, analytics, SEO, and omnichannel funnels.",
    career_dm_skills: "SEO, SEM, GA4, Ad Copywriting, Marketing Automation, Content Funnels",

    career_uiux_title: "UI / UX & Product Design",
    career_uiux_desc: "Design human-centered user experiences, wireframes, and design systems that AI cannot conceptualize.",
    career_uiux_skills: "Figma, User Research, Wireframing, Accessibility, Design Systems, UX Writing",

    career_da_title: "Data Analysis & BI",
    career_da_desc: "Transform raw organizational data into strategic executive dashboards and predictive business insights.",
    career_da_skills: "SQL, Python / Pandas, Power BI, Tableau, Statistical Modeling, Data Storytelling",

    career_cyber_title: "Cybersecurity & Defense",
    career_cyber_desc: "Protect critical digital infrastructure, cloud assets, and sensitive enterprise data from cyber threats.",
    career_cyber_skills: "Network Security, Linux, SOC Operations, SIEM Tools, Ethical Hacking, Incident Response",

    career_cloud_title: "Cloud & Infrastructure Support",
    career_cloud_desc: "Manage modern multi-cloud architectures, Kubernetes clusters, and automated serverless pipelines.",
    career_cloud_skills: "AWS, Microsoft Azure, Docker, Linux Administration, CI/CD, Terraform Basics",

    career_edu_title: "Teaching & Tech Training",
    career_edu_desc: "Train the next generation of engineers, corporate workforces, and students on modern AI and tech tools.",
    career_edu_skills: "Curriculum Design, Live Mentorship, Public Speaking, EdTech Platforms, Technical Writing",

    career_content_title: "Tech Content & DevRel",
    career_content_desc: "Bridge tech and audiences through tutorials, developer advocacy, YouTube, podcasts, and technical docs.",
    career_content_skills: "Video Production, Technical Storytelling, Developer Relations, Personal Branding, Scripting",

    career_pm_title: "Product Management",
    career_pm_desc: "Lead cross-functional engineering, design, and business teams to ship meaningful AI-powered software products.",
    career_pm_skills: "Product Roadmapping, Agile/Scrum, User Interviews, Metrics (CAC/LTV), Business Strategy",

    career_health_title: "Healthcare Technology",
    career_health_desc: "Develop and maintain secure digital health records, telemedicine solutions, and biomedical informatics.",
    career_health_skills: "Health Informatics, HL7/FHIR Standards, HIPAA Compliance, EHR Systems, Telehealth Ops",

    career_agri_title: "Digital Agriculture (AgriTech)",
    career_agri_desc: "Leverage IoT sensors, drone imagery, GIS maps, and automated analytics to revolutionize food systems.",
    career_agri_skills: "IoT Telemetry, GIS Mapping, Smart Irrigation Systems, Drone Data Analysis, Agri ERP",

    career_freelance_title: "Freelancing & Micro-Agency",
    career_freelance_desc: "Build solutions 5x faster using AI workflows and offer high-margin consulting to international clients.",
    career_freelance_skills: "Client Pitching, AI Prototyping, Full-Stack Building, Invoicing, Automation Pipelines",

    // Section 4: Skills Needed to Stay in IT
    sec4_badge: "Future-Proof Toolkit",
    sec4_title: "Skills Needed to Stay & Thrive in IT",
    sec4_subtitle: "Master these high-leverage technical and human skills to remain indispensable in the AI era.",
    skill_filter_all: "All Skills",
    skill_filter_ai: "AI-Native",
    skill_filter_tech: "Technical Core",
    skill_filter_human: "Human Power Skills",
    skill_card_importance: "Relevance Index",
    skill_card_keytools: "Key Tools / Areas:",

    skill_level_essential: "Essential (Must-Have)",
    skill_level_foundation: "Core Foundation",
    skill_level_high_demand: "High Industry Demand",
    skill_level_crucial: "Crucial for Everyone",
    skill_level_proof: "Proof of Work",
    skill_level_human_power: "AI-Proof Power Skill",
    skill_level_differentiator: "Highest Differentiator",
    skill_level_global_gate: "Global Career Gateway",

    skill_ai_title: "Using AI Tools Effectively",
    skill_ai_desc: "Master prompt engineering, Copilot pair programming, LLM APIs, and agentic workflows to multiply your productivity.",

    skill_py_title: "Python Programming",
    skill_py_desc: "The universal language of AI, data science, automation, backend APIs, and machine learning models.",

    skill_cloud_title: "Cloud Computing (AWS / Azure)",
    skill_cloud_desc: "Deploy, scale, and manage containerized applications, serverless compute, and modern cloud architecture.",

    skill_sec_title: "Cybersecurity Basics",
    skill_sec_desc: "Zero-trust fundamentals, OWASP security hygiene, secure coding practices, and identity access control.",

    skill_data_title: "Data Analysis & SQL",
    skill_data_desc: "Extract meaningful insights from relational databases, run aggregations, and build interactive executive dashboards.",

    skill_git_title: "GitHub & Project Building",
    skill_git_desc: "Collaborative Git workflows, CI/CD pipelines, open-source portfolio contributions, and live web deployments.",

    skill_comm_title: "Communication Skills",
    skill_comm_desc: "Express complex technical architecture clearly to stakeholders, write concise docs, and conduct impactful demos.",

    skill_ps_title: "Problem Solving & Architecture",
    skill_ps_desc: "Deconstruct ambiguous business problems from first principles and design resilient, cost-effective system architectures.",

    skill_team_title: "Creativity & Teamwork",
    skill_team_desc: "Foster cross-functional collaboration, design creative user-centric workflows, and resolve team blockers with empathy.",

    skill_eng_title: "English Communication",
    skill_eng_desc: "Fluent verbal and written English for global remote contracts, international client syncs, and documentation.",

    // Section 5: Quiz
    sec5_badge: "Interactive Assessment",
    sec5_title: "Can AI Replace Me? Interactive AI Readiness Quiz",
    sec5_subtitle: "Answer 4 quick questions to evaluate how AI affects your specific role and receive personalized career recommendations.",
    quiz_step: "Question",
    quiz_of: "of",
    quiz_next: "Next Question",
    quiz_prev: "Previous",
    quiz_calculate: "Calculate My Result",
    quiz_retake: "Retake Assessment",

    quiz_q1_text: "1. What is your current job role or background?",
    quiz_q1_opt1: "Manual Testing, Data Entry, Tech Support or Routine Ops",
    quiz_q1_opt2: "Core Software Developer (Frontend / Backend / Fullstack)",
    quiz_q1_opt3: "Cloud, DevOps, Data Engineer, or System Admin",
    quiz_q1_opt4: "UI/UX Designer, Product Manager, or Scrum Lead",
    quiz_q1_opt5: "College Student, Fresher, or Career Switcher",

    quiz_q2_text: "2. How frequently do you use AI tools in your daily routine?",
    quiz_q2_opt1: "Daily power user (Copilot, Claude, ChatGPT APIs, Prompting)",
    quiz_q2_opt2: "Occasionally (searching for code snippets or draft emails)",
    quiz_q2_opt3: "Rarely or never used modern AI tools",

    quiz_q3_text: "3. What is your current technical & problem-solving level?",
    quiz_q3_opt1: "Senior / Advanced: I solve complex architecture & business logic",
    quiz_q3_opt2: "Intermediate: I write code/features based on specs (1-3 yrs)",
    quiz_q3_opt3: "Beginner: I execute standard manual tasks following a checklist",

    quiz_q4_text: "4. Which area excites you most for future growth?",
    quiz_q4_opt1: "AI, Machine Learning & Intelligent Automation",
    quiz_q4_opt2: "Cybersecurity, Cloud Infrastructure & DevOps",
    quiz_q4_opt3: "Product Management, UI/UX & User Experience",
    quiz_q4_opt4: "Digital Marketing, Tech Training & Freelancing",

    // Quiz Results
    quiz_res1_title: "AI Will Assist Your Job",
    quiz_res1_badge: "Low Routine Risk • High Leverage",
    quiz_res1_desc: "Your role relies heavily on architectural judgment, high-level problem solving, and human leadership. AI will be your powerful co-pilot rather than a replacement.",
    quiz_res1_action: "Action: Deepen your AI workflow mastery and lead AI adoption in your team.",

    quiz_res2_title: "Your Role Will Change",
    quiz_res2_badge: "Moderate Transformation Required",
    quiz_res2_desc: "Your core tasks will evolve substantially. Writing standard boilerplate code or documentation will be done by AI, but domain expertise and system design will be in high demand.",
    quiz_res2_action: "Action: Upgrade from basic coding to AI tool integration, system architecture, and cloud deployment.",

    quiz_res3_title: "Learn New Skills Quickly",
    quiz_res3_badge: "High Automation Risk • Immediate Opportunity",
    quiz_res3_desc: "Routine manual tasks (manual testing, repetitive data entry, basic script execution) are being rapidly automated by AI agents. This is your cue to pivot into high-value domains.",
    quiz_res3_action: "Action: Start the 30-day or 90-day learning roadmap immediately to transition into AI, Cloud, or Cyber Defense.",
    quiz_recommended_path: "Recommended Next Step for You:",

    // Section 6: Roadmaps
    sec6_badge: "Actionable Milestones",
    sec6_title: "Step-by-Step Learning Roadmaps",
    sec6_subtitle: "Choose between rapid 30-day sprints and comprehensive 90-day master pathways with interactive progress tracking.",
    tab_30_days: "30-Day Sprint",
    tab_90_days: "90-Day Master Plan",
    track_ai: "AI & Data Science",
    track_cyber: "Cybersecurity Defense",
    track_cloud: "Cloud & DevOps",
    roadmap_progress: "Milestone Progress:",
    btn_start_learning: "Start Learning & Track Progress",
    roadmap_done: "Completed!",

    // Roadmap items
    rm_d1_7: "Days 1 – 7",
    rm_d8_15: "Days 8 – 15",
    rm_d16_22: "Days 16 – 22",
    rm_d23_30: "Days 23 – 30",
    rm_m1: "Month 1 (Days 1–30)",
    rm_m2: "Month 2 (Days 31–60)",
    rm_m3: "Month 3 (Days 61–90)",

    rm_30_ai_title: "AI & Data Sprint (30 Days)",
    rm_30_ai_subtitle: "Python, SQL, Prompt Engineering & Capstone Project",
    rm_30_ai_s1_t: "Python Core Essentials",
    rm_30_ai_s1_d: "Variables, data structures, loops, functions, and file handling.",
    rm_30_ai_s2_t: "SQL & Data Extraction",
    rm_30_ai_s2_d: "CRUD operations, multi-table JOINs, aggregation, and Pandas basics.",
    rm_30_ai_s3_t: "AI Tools & Prompt Engineering",
    rm_30_ai_s3_d: "Connecting to OpenAI/Claude APIs, prompt design, and AI automation.",
    rm_30_ai_s4_t: "Build & Deploy Capstone",
    rm_30_ai_s4_d: "Create an AI-powered CSV Data Explorer with Streamlit and push to GitHub.",

    rm_30_sec_title: "Cyber Defense Basics (30 Days)",
    rm_30_sec_subtitle: "Networking, Linux CLI, Web Security & Sandboxing",
    rm_30_sec_s1_t: "Networking Foundations",
    rm_30_sec_s1_d: "TCP/IP suite, OSI layers, DNS, subnetting, and HTTP/HTTPS traffic analysis.",
    rm_30_sec_s2_t: "Linux & Bash Scripting",
    rm_30_sec_s2_d: "Ubuntu terminal, user permissions, process management, and automation scripts.",
    rm_30_sec_s3_t: "OWASP Top 10 Security",
    rm_30_sec_s3_d: "Understanding SQL injection, XSS, CSRF, and safe authentication mechanisms.",
    rm_30_sec_s4_t: "Security Audit Project",
    rm_30_sec_s4_d: "Perform vulnerability scans with Nmap & Burp Suite in a safe sandbox environment.",

    rm_30_cld_title: "Cloud Kickstart (30 Days)",
    rm_30_cld_subtitle: "Linux, AWS Core Services, Docker & Web Deployment",
    rm_30_cld_s1_t: "Linux & Git Mastery",
    rm_30_cld_s1_d: "Command line proficiency, SSH key configuration, and Git repository management.",
    rm_30_cld_s2_t: "AWS / Azure Fundamentals",
    rm_30_cld_s2_d: "Compute instances (EC2), Object Storage (S3), IAM security, and networking.",
    rm_30_cld_s3_t: "Docker Containers",
    rm_30_cld_s3_d: "Containerizing web applications, writing Dockerfiles, and container networking.",
    rm_30_cld_s4_t: "Deploy Live Cloud Project",
    rm_30_cld_s4_d: "Deploy a production-ready website with SSL certificate and custom domain name.",

    rm_90_ai_title: "AI & Data Engineer Master (90 Days)",
    rm_90_ai_subtitle: "Production ML, Feature Engineering, RAG & Vector DBs",
    rm_90_ai_s1_t: "Advanced Python, SQL & EDA",
    rm_90_ai_s1_d: "Object-oriented programming, query performance tuning, NumPy, Pandas, and exploratory data analysis.",
    rm_90_ai_s2_t: "Machine Learning & BI Dashboards",
    rm_90_ai_s2_d: "Supervised algorithms with Scikit-learn, evaluation metrics, and interactive Power BI reports.",
    rm_90_ai_s3_t: "Generative AI, RAG & LLM Apps",
    rm_90_ai_s3_d: "Build production RAG pipelines with LangChain/LlamaIndex, Vector DBs, and deploy SaaS on Vercel.",

    rm_90_sec_title: "Cybersecurity Analyst Pathway (90 Days)",
    rm_90_sec_subtitle: "SOC Operations, SIEM, Threat Hunting & Security+",
    rm_90_sec_s1_t: "Deep Network & System Defense",
    rm_90_sec_s1_d: "Wireshark packet capture, Active Directory administration, and OS security hardening.",
    rm_90_sec_s2_t: "Ethical Hacking & Penetration Testing",
    rm_90_sec_s2_d: "Kali Linux tools, Metasploit, web vulnerability scanning, and defensive countermeasures.",
    rm_90_sec_s3_t: "SOC, SIEM & Incident Response",
    rm_90_sec_s3_d: "Splunk / ELK log ingestion, threat detection rules, incident handling, and Security+ readiness.",

    rm_90_cld_title: "DevOps & Cloud Architect (90 Days)",
    rm_90_cld_subtitle: "Kubernetes, Terraform IaC, CI/CD & Observability",
    rm_90_cld_s1_t: "Cloud Architecture & VPC Networking",
    rm_90_cld_s1_d: "Multi-tier cloud designs, Load Balancers, Auto-scaling groups, and fine-grained IAM policies.",
    rm_90_cld_s2_t: "Kubernetes & CI/CD Automation",
    rm_90_cld_s2_d: "K8s Pods, Services, Ingress controllers, and automated GitHub Actions delivery pipelines.",
    rm_90_cld_s3_t: "Terraform IaC & Cloud Monitoring",
    rm_90_cld_s3_d: "Infrastructure as Code with Terraform, Prometheus/Grafana metrics, and automated disaster recovery.",

    // Section 7: Final Message
    sec7_quote_highlight: "“IT will not disappear. IT will transform.",
    sec7_quote_body: "People who learn to work with AI will have better opportunities in the future.”",
    sec7_btn: "Start My Future Plan",
    sec7_summary_tip: "Save your personalized checklist and start learning today.",

    // Plan Builder Modal
    plan_modal_title: "Your 3-Year Future Action Plan",
    plan_modal_subtitle: "Customize your personalized roadmap and download your learning checklist.",
    plan_field_name: "Your Name / Role",
    plan_field_target: "Target Role for 2029",
    plan_field_timeframe: "Selected Timeframe",
    plan_checklist_title: "Your Personalized Action Checklist:",
    plan_item1: "Complete 1 modern AI tooling course (Prompting / Copilot / Cursor)",
    plan_item2: "Build and deploy 1 capstone project to GitHub with live URL",
    plan_item3: "Practice technical communication & English pitching weekly",
    plan_item4: "Network on LinkedIn with engineers in your target field",
    btn_print_plan: "Download / Print Action Plan",
    btn_save_plan: "Save Plan in Browser",
    saved_alert: "Plan saved successfully in your local browser storage!",

    // Footer
    footer_tagline: "IT 2029 — Learn. Adapt. Lead.",
    footer_desc: "Empowering developers, students, and tech professionals to navigate the AI revolution with clarity and confidence.",
    footer_col1_title: "Key Sections",
    footer_col2_title: "Alternative Careers",
    footer_col3_title: "Action Hub",
    footer_copy: "© 2026-2029 IT Transformation Guide. Built for engineers & learners worldwide.",
    btn_top: "Back to Top ↑"
  },

  ta: {
    // Nav
    nav_brand: "IT 2029 தொலைநோக்கு",
    nav_home: "முகப்பு",
    nav_after3yrs: "3 ஆண்டுகளில் IT",
    nav_careers: "மாற்றுத் தொழில்கள்",
    nav_skills: "தேவையான திறன்கள்",
    nav_quiz: "AI வினாடி வினா",
    nav_roadmaps: "கற்றல் வழிகள்",
    nav_future_plan: "எனது எதிர்காலத் திட்டம்",
    nav_lang_toggle: "English",

    // Hero Section
    hero_badge: "2026 – 2029 தொழில் பார்வை",
    hero_title: "அடுத்த 3 ஆண்டுகளில் IT துறை எப்படி மாறும்?",
    hero_subtitle: "IT துறை அழியாது. IT துறை AI உடன் உருமாறும்.",
    hero_desc: "எதிர்கால IT திறன்களைக் கற்றுக்கொள்ளுங்கள், மாற்றுத் தொழில் வாய்ப்புகளை ஆராயுங்கள், மற்றும் AI சார்ந்த வேலைவாய்ப்புகளுக்குத் தயாராகுங்கள்.",
    hero_btn_explore: "மாற்றுத் தொழில்கள்",
    hero_btn_quiz: "AI வினாடி வினா",
    hero_btn_roadmap: "கற்றல் வழிகள்",
    hero_stat1_num: "80%",
    hero_stat1_label: "வழக்கமான கோடிங் & டெஸ்டிங் AI மூலம் எளிதாகும்",
    hero_stat2_num: "97M+",
    hero_stat2_label: "உலகெங்கிலும் உருவாகும் புதிய AI & தொழில்நுட்பப் பணிகள்",
    hero_stat3_num: "100%",
    hero_stat3_label: "மனித ஆற்றல் & ஆக்கத்திறனுக்கான அதீத தேவை",

    // Section 2: IT After 3 Years
    sec2_badge: "எதிர்கால பார்வை",
    sec2_title: "3 ஆண்டுகளுக்குப் பின் IT: உண்மையில் என்ன நடக்கும்?",
    sec2_subtitle: "வழக்கமான உடல் உழைப்பு சார்ந்த பணிகளிலிருந்து AI சார்ந்த மேம்பட்ட இன்ஜினியரிங் முறைக்கான மாற்றம்.",

    trans_card1_tag: "ஆட்டோமேஷன் மாற்றம்",
    trans_card1_title: "வழக்கமான வேலைகளை AI தானியக்கமாக்கும்",
    trans_card1_desc: "அடிப்படை கோடிங், டெஸ்டிங், டேட்டா என்ட்ரி, டாக்குமெண்டேஷன் மற்றும் முதல் நிலை வாடிக்கையாளர் சேவை போன்ற பணிகளை AI தானியக்கமாக்கும்.",

    trans_card2_tag: "குழு கட்டமைப்பு",
    trans_card2_title: "வழக்கமான பணிகளுக்குக் குறைவான பணியாளர்கள்",
    trans_card2_desc: "தினசரி திரும்பத் திரும்பச் செய்யும் எளிய பணிகளுக்கு நிறுவனங்களுக்கு குறைவான பணியாளர்களே தேவைப்படலாம், ஏனெனில் AI அவற்றை 10 மடங்கு வேகமாகச் செய்யும்.",

    trans_card3_tag: "உண்மை நிலை",
    trans_card3_title: "IT அழியாது; அது உருமாறும்",
    trans_card3_desc: "IT துறை ஒருபோதும் முடிவுக்கு வராது—மாறாக மேம்படும். சாஃப்ட்வேர் அமைப்புகள் மேலும் விரிவடையும், அவற்றை நிர்வகிக்க AI மேற்பார்வையாளர்களும் ஆர்கிடெக்டுகளும் தேவை.",

    trans_card4_tag: "வளரும் துறைகள்",
    trans_card4_title: "புதிய தொழில்நுட்பங்களில் பெரும் வளர்ச்சி",
    trans_card4_desc: "செயற்கை நுண்ணறிவு (AI), கிளவுட் கம்ப்யூட்டிங், சைபர் செக்யூரிட்டி, டேட்டா அனலிடிக்ஸ், ரோபாட்டிக்ஸ் மற்றும் டிஜிட்டல் சேவைகளில் புதிய வேலைவாய்ப்புகள் வேகமாக வளரும்.",

    trans_card5_tag: "மனித மேலாதிக்கம்",
    trans_card5_title: "மனித திறன்கள் முதலிடம் பெறும்",
    trans_card5_desc: "படைப்பாற்றல் (Creativity), தகவல் தொடர்பு (Communication), குழுப்பணி (Teamwork) மற்றும் சிக்கல் தீர்க்கும் திறன் (Problem Solving) ஆகியவை மிக முக்கியமானதாக மாறும்.",

    // Section 3: Alternative Careers
    sec3_badge: "தொழில் பாதுகாப்பு",
    sec3_title: "ஒரு IT பணி பாதிக்கப்பட்டால், ஊழியர்கள் என்ன செய்யலாம்?",
    sec3_subtitle: "உங்கள் தொழில்நுட்ப அறிவைப் பயன்படுத்தி மிக வேகமாக நுழையக்கூடிய 11 உயர் வளர்ச்சி மாற்றுத் தொழில் வழிகளை ஆராயுங்கள்.",
    filter_all: "அனைத்து தொழில்கள்",
    filter_tech: "டெக் & டேட்டா",
    filter_creative: "டிசைன் & படைப்பு",
    filter_business: "வணிகம் & மேலாண்மை",
    filter_domain: "வளர்ந்து வரும் துறைகள்",
    btn_skills_needed: "தேவையான திறன்கள் & வழிகாட்டி",
    modal_demand: "சந்தை தேவை",
    modal_time: "மாற ஆகும் காலம்",
    modal_salary: "சம்பள வளர்ச்சி விகிதம்",
    modal_primary_skills: "முக்கிய திறன்கள்:",
    modal_tips_title: "தொழில் மாற்ற உத்தி:",
    modal_close: "மூடுக",

    career_dm_title: "டிஜிட்டல் மார்க்கெட்டிங் & குரோத்",
    career_dm_desc: "AI விளம்பர கருவிகள், அனலிடிக்ஸ், SEO மற்றும் டிஜிட்டல் விளம்பரங்கள் மூலம் வணிக வளர்ச்சியை உருவாக்குங்கள்.",
    career_dm_skills: "SEO, SEM, Google Analytics 4, விளம்பர காப்பிரைட்டிங், மார்க்கெட்டிங் ஆட்டோமேஷன்",

    career_uiux_title: "UI / UX & தயாரிப்பு வடிவமைப்பு",
    career_uiux_desc: "AI உருவாக்க முடியாத மனித தேவைகளை உணர்ந்த பயனர் அனுபவங்கள் (UX) மற்றும் இன்டர்பேஸ்களை உருவாக்குங்கள்.",
    career_uiux_skills: "Figma, பயனர் ஆராய்ச்சி (User Research), புரோட்டோடைப்பிங், டிசைன் சிஸ்டம்ஸ்",

    career_da_title: "டேட்டா அனலிசிஸ் & பிசினஸ் இன்சைட்ஸ்",
    career_da_desc: "நிறுவனத்தின் மூலத் தரவுகளை அலசி வணிக முடிவுகளுக்கான டாஷ்போர்டுகளாகவும் வரைபடங்களாகவும் மாற்றுங்கள்.",
    career_da_skills: "SQL, Python / Pandas, Power BI, Tableau, புள்ளிவிவர பகுப்பாய்வு",

    career_cyber_title: "சைபர் செக்யூரிட்டி & பாதுகாப்பு",
    career_cyber_desc: "நிறுவனங்களின் முக்கிய டேட்டா, கிளவுட் அமைப்புகள் மற்றும் நெட்வொர்க்குகளை ஹேக்கர்களிடமிருந்து பாதுகாக்கவும்.",
    career_cyber_skills: "நெட்வொர்க் பாதுகாப்பு, Linux, SOC செயல்பாடுகள், SIEM டூல்ஸ், எத்திக்கல் ஹேக்கிங்",

    career_cloud_title: "கிளவுட் & இன்ஃப்ராஸ்ட்ரக்சர் சப்போர்ட்",
    career_cloud_desc: "நவீன கிளவுட் கட்டமைப்புகள், டாக்கர் கன்டெய்னர்கள் மற்றும் சர்வர் மேலாண்மையை திறம்பட கையாளுங்கள்.",
    career_cloud_skills: "AWS, Microsoft Azure, Docker, Linux SysAdmin, CI/CD, Terraform",

    career_edu_title: "கற்பித்தல் & டெக் பயிற்சி (Training)",
    career_edu_desc: "அடுத்த தலைமுறை இன்ஜினியர்களுக்கும் நிறுவன ஊழியர்களுக்கும் AI மற்றும் புதிய தொழில்நுட்பங்களைக் கற்பியுங்கள்.",
    career_edu_skills: "பாடத்திட்டம் உருவாக்குதல், நேரடி பயிற்சி, மேடைப் பேச்சு, EdTech கருவிகள், டெக்னிக்கல் ரைட்டிங்",

    career_content_title: "டெக் கன்டென்ட் & டெவலப்பர் ரிலேஷன்ஸ்",
    career_content_desc: "யூடியூப், போட்காஸ்ட் மற்றும் சமூக ஊடகங்கள் வழியாக தொழில்நுட்பங்களை எளிய முறையில் விளக்கி வருவாய் ஈட்டுங்கள்.",
    career_content_skills: "வீடியோ எடிட்டிங், தொழில்நுட்ப விளக்கம், டெவலப்பர் ரிலேஷன்ஸ், பர்சனல் பிராண்டிங்",

    career_pm_title: "தயாரிப்பு மேலாண்மை (Product Management)",
    career_pm_desc: "இன்ஜினியரிங், டிசைன் மற்றும் வணிகக் குழுக்களை வழிநடத்தி வெற்றிகரமான மென்பொருள் தயாரிப்புகளை உருவாக்குங்கள்.",
    career_pm_skills: "புராடக்ட் ரோட்மேப், Agile/Scrum, பயனர் சந்திப்புகள், வணிக உத்திகள் (ROI, CAC)",

    career_health_title: "ஹெல்த்கேர் டெக்னாலஜி (மருத்துவத் துறை)",
    career_health_desc: "டிஜிட்டல் மருத்துவக் குறிப்புகள், டெலிமெடிசின் தளங்கள் மற்றும் மருத்துவத் துறை சாஃப்ட்வேர்களை உருவாக்குங்கள்.",
    career_health_skills: "HL7/FHIR நெறிமுறைகள், HIPAA விதிமுறைகள், EHR சிஸ்டம்ஸ், டெலிஹெல்த் ஆப்ஸ்",

    career_agri_title: "டிஜிட்டல் வேளாண்மை (AgriTech)",
    career_agri_desc: "IoT சென்சார்கள், ட்ரோன் புகைப்படங்கள் மற்றும் ஜிஐஎஸ் மேப்பிங் மூலம் விவசாயத்தை நவீனமயமாக்குங்கள்.",
    career_agri_skills: "IoT சென்சார்கள், ஜிஐஎஸ் வரைபடங்கள், ஸ்மார்ட் பாசன ஆட்டோமேஷன், அக்ரி ERP",

    career_freelance_title: "ஃப்ரீலான்சிங் & சிறு வணிகம்",
    career_freelance_desc: "AI டூல்ஸ் மூலம் 5 மடங்கு வேகமாக பணிகளை முடித்து உலகளாவிய வாடிக்கையாளர்களுக்கு நேரடியாக சேவை அளியுங்கள்.",
    career_freelance_skills: "வாடிக்கையாளர் ஈர்ப்பு, AI புரோட்டோடைப்பிங், ஃபுல்-ஸ்டேக் பில்டிங், ஆட்டோமேஷன்",

    // Section 4: Skills Needed to Stay in IT
    sec4_badge: "எதிர்கால திறன்கள்",
    sec4_title: "IT துறையில் நிலைத்திருக்கத் தேவையான முக்கிய திறன்கள்",
    sec4_subtitle: "AI யுகத்தில் எப்போதும் மதிப்புமிக்கவராக விளங்க இந்த நவீன தொழில்நுட்ப மற்றும் மனித திறன்களைக் கற்றுக்கொள்ளுங்கள்.",
    skill_filter_all: "அனைத்து திறன்கள்",
    skill_filter_ai: "AI சார்ந்த திறன்கள்",
    skill_filter_tech: "முக்கிய தொழில்நுட்பம்",
    skill_filter_human: "மனித ஆற்றல் திறன்கள்",
    skill_card_importance: "முக்கியத்துவ குறியீடு",
    skill_card_keytools: "முக்கிய கருவிகள் / பகுதிகள்:",

    skill_level_essential: "அத்தியாவசியம் (கட்டாயம் தேவை)",
    skill_level_foundation: "அடிப்படை அடித்தளம்",
    skill_level_high_demand: "அதிக சந்தை தேவை",
    skill_level_crucial: "அனைவருக்கும் முக்கியம்",
    skill_level_proof: "திறமைக்கான ஆதாரம்",
    skill_level_human_power: "AI மாற்ற முடியாத மனித சக்தி",
    skill_level_differentiator: "மிக உயர்ந்த தனித்துவத் திறன்",
    skill_level_global_gate: "உலகளாவிய வாய்ப்புகளுக்கான திறவுகோல்",

    skill_ai_title: "AI கருவிகளைப் பயன்படுத்துதல்",
    skill_ai_desc: "ப்ராம்ப்ட் இன்ஜினியரிங், கோபைலட் மற்றும் AI ஏஜென்ட்களைப் பயன்படுத்தி உங்கள் வேலைத்திறனை 5 மடங்கு பெருக்குங்கள்.",

    skill_py_title: "பைதான் அல்லது நிரலாக்க மொழி",
    skill_py_desc: "AI, டேட்டா சயின்ஸ், ஆட்டோமேஷன் மற்றும் பேக்-எண்ட் உருவாக்கத்திற்கு உலகளவில் பயன்படும் முதன்மை மொழி.",

    skill_cloud_title: "கிளவுட் கம்ப்யூட்டிங் (AWS / Azure)",
    skill_cloud_desc: "நவீன கிளவுட் சர்வர்கள், டாக்கர் கன்டெய்னர்கள் மற்றும் சர்வர்லெஸ் கட்டமைப்புகளை நிர்வகிக்கக் கற்றுக்கொள்ளுங்கள்.",

    skill_sec_title: "சைபர் செக்யூரிட்டி அடிப்படைகள்",
    skill_sec_desc: "ஜீரோ டிரஸ்ட் கொள்கை, இணையதள பாதுகாப்பு நெறிமுறைகள் மற்றும் டேட்டா பாதுகாப்பு முறைகளை அறிந்துகொள்ளுங்கள்.",

    skill_data_title: "டேட்டா அனலிசிஸ் & SQL",
    skill_data_desc: "டேட்டாபேஸ்களில் இருந்து தகவல்களை எடுத்து, வரைபட டாஷ்போர்டுகளாக மாற்றி வணிக முடிவுகளுக்கு உதவுங்கள்.",

    skill_git_title: "GitHub & திட்டங்கள் உருவாக்குதல்",
    skill_git_desc: "Git பதிப்புக் கட்டுப்பாடு, திறந்த மூல பங்களிப்புகள் மற்றும் நேரடி வலைத்தள வெளியீடு (Deployments).",

    skill_comm_title: "தகவல் தொடர்புத் திறன் (Communication)",
    skill_comm_desc: "சிக்கலான தொழில்நுட்பங்களை எளிய முறையில் விளக்குதல், தெளிவான எழுத்து மற்றும் பிரசன்டேஷன் திறன்.",

    skill_ps_title: "சிக்கல் தீர்க்கும் திறன் (Problem Solving)",
    skill_ps_desc: "குழப்பமான வணிக தேவைகளைப் பகுப்பாய்வு செய்து சிறந்த, சிக்கனமான தொழில்நுட்பத் தீர்வுகளை வடிவமைத்தல்.",

    skill_team_title: "படைப்பாற்றல் & குழுப்பணி",
    skill_team_desc: "புதுமையான சிந்தனை, சக ஊழியர்களுடன் இணைந்து பணியாற்றுதல் மற்றும் வாடிக்கையாளர் தேவைகளை உணர்தல்.",

    skill_eng_title: "ஆங்கிலப் பேச்சு & எழுத்துத் திறன்",
    skill_eng_desc: "உலகளாவிய வாடிக்கையாளர்களுடன் பேசுவதற்கும் சர்வதேச தொலைதூர வேலைகளுக்கும் தெளிவான ஆங்கிலம் அவசியம்.",

    // Section 5: Quiz
    sec5_badge: "சுய மதிப்பீடு",
    sec5_title: "AI என்னை மாற்றிவிடுமா? AI வினாடி வினா",
    sec5_subtitle: "4 எளிய கேள்விகளுக்குப் பதிலளித்து உங்கள் துறைக்கு AI ஏற்படுத்தும் தாக்கத்தை அறிந்து தனிப்பயனாக்கப்பட்ட ஆலோசனைகளைப் பெறுங்கள்.",
    quiz_step: "கேள்வி",
    quiz_of: "இல்",
    quiz_next: "அடுத்த கேள்வி",
    quiz_prev: "முந்தையது",
    quiz_calculate: "முடிவைக் காண்க",
    quiz_retake: "மீண்டும் செய்",

    quiz_q1_text: "1. உங்கள் தற்போதைய வேலை அல்லது பின்னணி என்ன?",
    quiz_q1_opt1: "மேனுவல் டெஸ்டிங், டேட்டா என்ட்ரி, டெக் சப்போர்ட் அல்லது எளிய வழக்கமான பணிகள்",
    quiz_q1_opt2: "சாஃப்ட்வேர் டெவலப்பர் (Frontend / Backend / Fullstack)",
    quiz_q1_opt3: "கிளவுட், டெவொப்ஸ், டேட்டா இன்ஜினியர் அல்லது சிஸ்டம் அட்மின்",
    quiz_q1_opt4: "UI/UX டிசைனர், புராடக்ட் மேனேஜர் அல்லது ஸ்க்ரம் மாஸ்டர்",
    quiz_q1_opt5: "கல்லூரி மாணவர், ஃப்ரெஷர் அல்லது புதிய தொழில் கற்பவர்",

    quiz_q2_text: "2. நீங்கள் தினசரி வேலையில் AI கருவிகளை எவ்வளவு அடிக்கடி பயன்படுத்துகிறீர்கள்?",
    quiz_q2_opt1: "தினமும் அதிகளவில் (Copilot, Claude, ChatGPT, Prompting)",
    quiz_q2_opt2: "எப்போதாவது (சிறு சந்தேகங்கள் அல்லது மின்னஞ்சல் வரைவுக்கு)",
    quiz_q2_opt3: "அரிதாக அல்லது இதுவரை AI கருவிகளைப் பயன்படுத்தியதில்லை",

    quiz_q3_text: "3. உங்கள் தற்போதைய தொழில்நுட்ப மற்றும் சிக்கல் தீர்க்கும் திறன் எந்த அளவில் உள்ளது?",
    quiz_q3_opt1: "சீனியர் / நிபுணர்: கடினமான ஆர்கிடெக்சர் மற்றும் சிக்கல்களை சுயமாக தீர்ப்பேன்",
    quiz_q3_opt2: "இடைநிலை (1-3 ஆண்டுகள்): கொடுக்கப்பட்ட தேவைகளுக்கு ஏற்ப கோடிங் செய்வேன்",
    quiz_q3_opt3: "தொடக்க நிலை: பட்டியலிடப்பட்ட அடிப்படை வேலைகளை மட்டுமே செய்வேன்",

    quiz_q4_text: "4. எதிர்கால வளர்ச்சிக்கு உங்களை மிகவும் ஈர்க்கும் துறை எது?",
    quiz_q4_opt1: "செயற்கை நுண்ணறிவு (AI), மெஷின் லேர்னிங் & ஆட்டோமேஷன்",
    quiz_q4_opt2: "சைபர் செக்யூரிட்டி, கிளவுட் இன்ஃப்ராஸ்ட்ரக்சர் & DevOps",
    quiz_q4_opt3: "புராடக்ட் மேனேஜ்மென்ட், UI/UX & பயனர் அனுபவம்",
    quiz_q4_opt4: "டிஜிட்டல் மார்க்கெட்டிங், டெக் பயிற்சி & ஃப்ரீலான்சிங்",

    // Quiz Results
    quiz_res1_title: "AI உங்கள் வேலைக்கு உதவும் (AI Will Assist)",
    quiz_res1_badge: "குறைந்த ஆபத்து • அதிக செயல்திறன்",
    quiz_res1_desc: "உங்கள் பணி உயர் மட்ட சிந்தனை, சிக்கல் தீர்க்கும் திறன் மற்றும் தலைமைப் பண்புகளை சார்ந்துள்ளது. AI உங்களை மாற்றுவதற்குப் பதிலாக உங்கள் திறனைப் பெருக்கும் கூட்டாளியாக அமையும்.",
    quiz_res1_action: "நடவடிக்கை: AI கருவிகளை முழுமையாகப் பயன்படுத்தி உங்கள் குழுவை வழிநடத்துங்கள்.",

    quiz_res2_title: "உங்கள் பணிப் பொறுப்பு மாறும் (Role Will Change)",
    quiz_res2_badge: "நடுத்தர மாற்றம் தேவை",
    quiz_res2_desc: "உங்கள் வழக்கமான எளிய கோடிங் மற்றும் ஆவண வேலைகளை AI செய்யும். ஆனால் சிஸ்டம் டிசைன் மற்றும் வணிக தேவைகளை புரிந்துகொள்ளும் இன்ஜினியர்களுக்கு மதிப்பு கூடும்.",
    quiz_res2_action: "நடவடிக்கை: வழக்கமான பணிகளிலிருந்து AI டூல் ஒருங்கிணைப்பு மற்றும் கிளவுட் கட்டமைப்பிற்கு மேம்படுங்கள்.",

    quiz_res3_title: "புதிய திறன்களை உடனே கற்கவும் (Learn Quickly)",
    quiz_res3_badge: "உடனடி நடவடிக்கை தேவை • புதிய வாய்ப்புகள்",
    quiz_res3_desc: "வழக்கமான மேனுவல் பணிகள் (மேனுவல் டெஸ்டிங், டேட்டா என்ட்ரி) AI மூலம் வேகமாக தானியக்கமாக்கப்படுகின்றன. இது நீங்கள் புதிய உயர் மதிப்புள்ள துறைகளுக்கு மாற சிறந்த நேரம்.",
    quiz_res3_action: "நடவடிக்கை: உடனே 30 நாள் அல்லது 90 நாள் கற்றல் திட்டத்தைத் தொடங்கி AI, கிளவுட் அல்லது சைபர் செக்யூரிட்டிக்கு மாறுங்கள்.",
    quiz_recommended_path: "உங்களுக்கான பரிந்துரைக்கப்பட்ட கற்றல் வழி:",

    // Section 6: Roadmaps
    sec6_badge: "கற்றல் வழிகாட்டி",
    sec6_title: "படிப்படியான கற்றல் சாலை வரைபடம் (Roadmaps)",
    sec6_subtitle: "30 நாள் விரைவுத் திட்டம் அல்லது 90 நாள் முழுமையான நிபுணர் பாதையைத் தேர்ந்தெடுத்து உங்கள் முன்னேற்றத்தைக் கண்காணிக்கவும்.",
    tab_30_days: "30 நாள் விரைவுத் திட்டம்",
    tab_90_days: "90 நாள் முழுமையான திட்டம்",
    track_ai: "AI & டேட்டா சயின்ஸ்",
    track_cyber: "சைபர் செக்யூரிட்டி",
    track_cloud: "கிளவுட் & டெவொப்ஸ்",
    roadmap_progress: "கற்றல் முன்னேற்றம்:",
    btn_start_learning: "கற்கத் தொடங்கு & முன்னேற்றத்தைக் குறி",
    roadmap_done: "முடித்தாயிற்று!",

    // Roadmap items
    rm_d1_7: "நாட்கள் 1 – 7",
    rm_d8_15: "நாட்கள் 8 – 15",
    rm_d16_22: "நாட்கள் 16 – 22",
    rm_d23_30: "நாட்கள் 23 – 30",
    rm_m1: "மாதம் 1 (நாட்கள் 1–30)",
    rm_m2: "மாதம் 2 (நாட்கள் 31–60)",
    rm_m3: "மாதம் 3 (நாட்கள் 61–90)",

    rm_30_ai_title: "AI & டேட்டா 30 நாள் திட்டம்",
    rm_30_ai_subtitle: "பைதான், SQL, AI ப்ராம்ப்ட்டிங் & இறுதி புராஜெக்ட்",
    rm_30_ai_s1_t: "பைதான் அடிப்படை திறன்கள்",
    rm_30_ai_s1_d: "வேரியபிள்கள், லூப்புகள், ஃபங்ஷன்கள் மற்றும் ஃபைல் கையாளுதல்.",
    rm_30_ai_s2_t: "SQL & டேட்டா கையாளுதல்",
    rm_30_ai_s2_d: "CRUD குவரிகள், பல அட்டவணை இணைப்புகள் (JOINs) மற்றும் Pandas அடிப்படைகள்.",
    rm_30_ai_s3_t: "AI கருவிகள் & ப்ராம்ப்ட் இன்ஜினியரிங்",
    rm_30_ai_s3_d: "OpenAI / Claude API இணைப்பு, ப்ராம்ப்ட் வடிவமைப்பு மற்றும் ஆட்டோமேஷன்.",
    rm_30_ai_s4_t: "புராஜெக்ட் உருவாக்கி வெளியிடுதல்",
    rm_30_ai_s4_d: "Streamlit மூலம் AI டேட்டா அனலைசர் உருவாக்கி GitHub-ல் வெளியிடவும்.",

    rm_30_sec_title: "சைபர் பாதுகாப்பு 30 நாள் திட்டம்",
    rm_30_sec_subtitle: "நெட்வொர்க்கிங், Linux, வெப் பாதுகாப்பு அடிப்படைகள்",
    rm_30_sec_s1_t: "நெட்வொர்க்கிங் அடிப்படைகள்",
    rm_30_sec_s1_d: "TCP/IP, OSI அடுக்குகள், DNS, சப்நெட்டிங் மற்றும் HTTP/HTTPS நெறிமுறைகள்.",
    rm_30_sec_s2_t: "Linux & Bash ஸ்கிரிப்டிங்",
    rm_30_sec_s2_d: "Ubuntu டெர்மினல், அனுமதிகள், செயல்முறைகள் மற்றும் ஆட்டோமேஷன் ஸ்கிரிப்ட்கள்.",
    rm_30_sec_s3_t: "OWASP டாப் 10 வெப் பாதுகாப்பு",
    rm_30_sec_s3_d: "SQL Injection, XSS குறைபாடுகளைப் புரிந்துகொண்டு பாதுகாப்பு வழிமுறைகளை அறிதல்.",
    rm_30_sec_s4_t: "பாதுகாப்பு தணிக்கை திட்டம்",
    rm_30_sec_s4_d: "Nmap & Burp Suite மூலம் சோதனை சூழலில் பாதுகாப்பு ஸ்கேன் செய்தல்.",

    rm_30_cld_title: "கிளவுட் 30 நாள் திட்டம்",
    rm_30_cld_subtitle: "Linux, AWS அடிப்படைகள், Docker & வெப் வெளியீடு",
    rm_30_cld_s1_t: "Linux & Git அடிப்படைகள்",
    rm_30_cld_s1_d: "கமாண்ட் லைன் பயன்பாடு, SSH சாவிகள் மற்றும் Git களஞ்சிய மேலாண்மை.",
    rm_30_cld_s2_t: "AWS / Azure முக்கிய சேவைகள்",
    rm_30_cld_s2_d: "EC2 விர்ச்சுவல் மெஷின், S3 ஸ்டோரேஜ், IAM பாதுகாப்பு மற்றும் நெட்வொர்க்.",
    rm_30_cld_s3_t: "Docker கன்டெய்னர்கள்",
    rm_30_cld_s3_d: "வலைப் பயன்பாடுகளை கன்டெய்னராக்குதல், Dockerfile எழுதுதல் மற்றும் இயக்குதல்.",
    rm_30_cld_s4_t: "கிளவுடில் வெப்சைட் வெளியீடு",
    rm_30_cld_s4_d: "SSL சான்றிதழுடன் உங்கள் சொந்த டொமைனில் வலைத்தளத்தை ஹோஸ்ட் செய்தல்.",

    rm_90_ai_title: "AI & டேட்டா சயின்ஸ் 90 நாள் திட்டம்",
    rm_90_ai_subtitle: "மெஷின் லேர்னிங், RAG, வெக்டர் டேட்டாபேஸ் & SaaS உருவாக்கம்",
    rm_90_ai_s1_t: "மேம்பட்ட பைதான், SQL & டேட்டா ஆய்வு",
    rm_90_ai_s1_d: "OOP கொள்கைகள், வேகமான SQL குவரிகள், NumPy, Pandas மற்றும் தரவு ஆய்வு.",
    rm_90_ai_s2_t: "மெஷின் லேர்னிங் & Power BI டாஷ்போர்டு",
    rm_90_ai_s2_d: "Scikit-learn அல்காரிதம்கள், வகைப்பாடு மற்றும் இன்டராக்டிவ் Power BI அறிக்கைகள்.",
    rm_90_ai_s3_t: "ஜெனரேட்டிவ் AI, RAG & LLM பயன்பாடுகள்",
    rm_90_ai_s3_d: "LangChain, Vector DB கொண்டு AI தேடுபொறி உருவாக்கி Vercel-ல் வெளியிடவும்.",

    rm_90_sec_title: "சைபர் செக்யூரிட்டி அனலிஸ்ட் 90 நாள் திட்டம்",
    rm_90_sec_subtitle: "SOC செயல்பாடுகள், SIEM, தற்காப்பு & Security+ தயாரிப்பு",
    rm_90_sec_s1_t: "நெட்வொர்க் & ஆப்பரேட்டிங் சிஸ்டம் பாதுகாப்பு",
    rm_90_sec_s1_d: "Wireshark பாக்கெட் அனலிசிஸ், ஆக்டிவ் டைரக்டரி மற்றும் சிஸ்டம் பாதுகாப்பு.",
    rm_90_sec_s2_t: "எத்திக்கல் ஹேக்கிங் & ஊடுருவல் சோதனை",
    rm_90_sec_s2_d: "Kali Linux கருவிகள், Metasploit, இணைய பாதுகாப்பு குறைபாடுகளைக் கண்டறிதல்.",
    rm_90_sec_s3_t: "SOC, SIEM & அச்சுறுத்தல் தடுப்பு",
    rm_90_sec_s3_d: "Splunk / ELK லாக் பகுப்பாய்வு, பாதுகாப்பு நிகழ்வு மேலாண்மை மற்றும் போர்ட்ஃபோலியோ.",

    rm_90_cld_title: "டெவொப்ஸ் & கிளவுட் ஆர்கிடெக்ட் 90 நாள் திட்டம்",
    rm_90_cld_subtitle: "Kubernetes, Terraform IaC, CI/CD ஆட்டோமேஷன்",
    rm_90_cld_s1_t: "கிளவுட் ஆர்கிடெக்சர் & VPC நெட்வொர்க்கிங்",
    rm_90_cld_s1_d: "மல்டி-டயர் கிளவுட் வடிவமைப்பு, லோட் பேலன்சர்கள், ஆட்டோ ஸ்கேலிங் மற்றும் IAM.",
    rm_90_cld_s2_t: "Kubernetes & CI/CD ஆட்டோமேஷன்",
    rm_90_cld_s2_d: "K8s Pods, Services, Ingress மற்றும் GitHub Actions தானியங்கி பைப்லைன்கள்.",
    rm_90_cld_s3_t: "Terraform IaC & கிளவுட் கண்காணிப்பு",
    rm_90_cld_s3_d: "Terraform மூலம் தானியங்கி உள்கட்டமைப்பு, Prometheus/Grafana கண்காணிப்பு.",

    // Section 7: Final Message
    sec7_quote_highlight: "“IT துறை அழியாது. IT துறை உருமாறும்.",
    sec7_quote_body: "AI உடன் இணைந்து செயல்படக் கற்றுக்கொள்பவர்களுக்கே எதிர்காலத்தில் சிறந்த வாய்ப்புகள் கிடைக்கும்.”",
    sec7_btn: "எனது எதிர்காலத் திட்டத்தைத் தொடங்கு",
    sec7_summary_tip: "உங்கள் தனிப்பயனாக்கப்பட்ட திட்டத்தைச் சேமித்து இன்றே கற்கத் தொடங்குங்கள்.",

    // Plan Builder Modal
    plan_modal_title: "உங்கள் 3 ஆண்டு எதிர்கால செயல் திட்டம்",
    plan_modal_subtitle: "உங்கள் விருப்பங்களை அமைத்து தனிப்பயனாக்கப்பட்ட சரிபார்ப்புப் பட்டியலைப் பதிவிறக்குங்கள்.",
    plan_field_name: "உங்கள் பெயர் / தற்போதைய பணி",
    plan_field_target: "2029-ல் நீங்கள் அடைய விரும்பும் இலக்கு பணி",
    plan_field_timeframe: "தேர்ந்தெடுக்கப்பட்ட கால அளவு",
    plan_checklist_title: "உங்கள் தனிப்பட்ட செயல் பட்டியல்:",
    plan_item1: "1 நவீன AI கருவி பயிற்சியை முடிக்கவும் (Prompting / Copilot / Cursor)",
    plan_item2: "1 முக்கிய புராஜெக்ட்டை உருவாக்கி GitHub-ல் நேரலை URL உடன் வெளியிடவும்",
    plan_item3: "வாரந்தோறும் தொழில்நுட்ப ஆங்கிலம் மற்றும் பிரசன்டேஷன் பயிற்சி செய்யவும்",
    plan_item4: "LinkedIn-ல் இலக்கு துறை நிபுணர்களுடன் தொடர்பை ஏற்படுத்தவும்",
    btn_print_plan: "திட்டத்தைப் பதிவிறக்கு / அச்சிடு",
    btn_save_plan: "பிரவுசரில் திட்டத்தைச் சேமிக்கவும்",
    saved_alert: "திட்டம் உங்கள் பிரவுசரில் வெற்றிகரமாகச் சேமிக்கப்பட்டது!",

    // Footer
    footer_tagline: "IT 2029 — கற்போம். மாற்றமடைவோம். வழிநடத்துவோம்.",
    footer_desc: "டெவலப்பர்கள், மாணவர்கள் மற்றும் தொழில்நுட்ப வல்லுநர்கள் AI புரட்சியை நம்பிக்கையுடன் எதிர்கொள்ள உதவும் தளம்.",
    footer_col1_title: "முக்கிய பகுதிகள்",
    footer_col2_title: "மாற்றுத் தொழில்கள்",
    footer_col3_title: "செயல் மையம்",
    footer_copy: "© 2026-2029 IT Transformation Guide. உலகளாவிய பொறியாளர்களுக்காக உருவாக்கப்பட்டது.",
    btn_top: "மேலே செல்க ↑"
  }
};
