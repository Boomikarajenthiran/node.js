// Data definitions for Careers, Skills, Roadmaps, and Quiz

const DATA = {
  transformationPoints: [
    {
      id: "automation",
      icon: "bot",
      titleKey: "trans_card1_title",
      descKey: "trans_card1_desc",
      tagKey: "trans_card1_tag",
      badgeType: "warning"
    },
    {
      id: "lean_teams",
      icon: "users-round",
      titleKey: "trans_card2_title",
      descKey: "trans_card2_desc",
      tagKey: "trans_card2_tag",
      badgeType: "info"
    },
    {
      id: "evolution",
      icon: "refresh-cw",
      titleKey: "trans_card3_title",
      descKey: "trans_card3_desc",
      tagKey: "trans_card3_tag",
      badgeType: "success"
    },
    {
      id: "growth_areas",
      icon: "trending-up",
      titleKey: "trans_card4_title",
      descKey: "trans_card4_desc",
      tagKey: "trans_card4_tag",
      badgeType: "accent"
    },
    {
      id: "human_skills",
      icon: "sparkles",
      titleKey: "trans_card5_title",
      descKey: "trans_card5_desc",
      tagKey: "trans_card5_tag",
      badgeType: "gold"
    }
  ],

  careers: [
    {
      id: "digital_marketing",
      icon: "target",
      category: "business",
      titleKey: "career_dm_title",
      descKey: "career_dm_desc",
      skillsKey: "career_dm_skills",
      demandLevel: "High",
      timeToTransition: "2-4 Months",
      avgSalaryGrowth: "+35%",
      primarySkills: ["SEO & SEM", "Google Analytics 4", "AI Ad Copywriting", "Social Media Strategy", "Conversion Funnels"],
      transitionTips: "Utilize your tech understanding of web architecture, data tracking, and analytics to excel in performance marketing."
    },
    {
      id: "ui_ux_design",
      icon: "layout",
      category: "design",
      titleKey: "career_uiux_title",
      descKey: "career_uiux_desc",
      skillsKey: "career_uiux_skills",
      demandLevel: "Very High",
      timeToTransition: "3-5 Months",
      avgSalaryGrowth: "+40%",
      primarySkills: ["Figma / FigJam", "User Research & Personas", "Design Systems", "Wireframing & Prototyping", "UX Copywriting"],
      transitionTips: "Front-end and QA developers can leverage their layout knowledge to design human-centered, accessible interfaces."
    },
    {
      id: "data_analysis",
      icon: "bar-chart-3",
      category: "data",
      titleKey: "career_da_title",
      descKey: "career_da_desc",
      skillsKey: "career_da_skills",
      demandLevel: "Extremely High",
      timeToTransition: "3-6 Months",
      avgSalaryGrowth: "+45%",
      primarySkills: ["SQL & Database Queries", "Python (Pandas, Numpy)", "Power BI / Tableau", "Statistical Analysis", "Data Storytelling"],
      transitionTips: "Ideal for anyone who works with spreadsheets, backend databases, or reporting systems."
    },
    {
      id: "cybersecurity",
      icon: "shield-alert",
      category: "security",
      titleKey: "career_cyber_title",
      descKey: "career_cyber_desc",
      skillsKey: "career_cyber_skills",
      demandLevel: "Extremely High",
      timeToTransition: "4-6 Months",
      avgSalaryGrowth: "+50%",
      primarySkills: ["Network Security & Protocols", "Linux & Shell Scripting", "SOC Operations & SIEM", "Vulnerability Assessment", "CompTIA Security+"],
      transitionTips: "System administrators and network engineers can smoothly transition into defensive security & incident response."
    },
    {
      id: "cloud_support",
      icon: "cloud",
      category: "infrastructure",
      titleKey: "career_cloud_title",
      descKey: "career_cloud_desc",
      skillsKey: "career_cloud_skills",
      demandLevel: "Very High",
      timeToTransition: "2-4 Months",
      avgSalaryGrowth: "+35%",
      primarySkills: ["AWS / Microsoft Azure", "Linux SysAdmin", "Docker & Containers", "Terraform & IaC Basics", "CI/CD Deployment"],
      transitionTips: "High-growth path for IT support specialists and junior developers looking to manage modern cloud infrastructure."
    },
    {
      id: "tech_training",
      icon: "graduation-cap",
      category: "education",
      titleKey: "career_edu_title",
      descKey: "career_edu_desc",
      skillsKey: "career_edu_skills",
      demandLevel: "Moderate-High",
      timeToTransition: "1-3 Months",
      avgSalaryGrowth: "+30%",
      primarySkills: ["Curriculum Design", "Public Speaking", "EdTech LMS Tools", "Live Code Mentorship", "Technical Writing"],
      transitionTips: "Experienced engineers can monetize their practical knowledge by teaching upcoming engineers and corporate teams."
    },
    {
      id: "content_creation",
      icon: "video",
      category: "creative",
      titleKey: "career_content_title",
      descKey: "career_content_desc",
      skillsKey: "career_content_skills",
      demandLevel: "High",
      timeToTransition: "1-3 Months",
      avgSalaryGrowth: "+40%",
      primarySkills: ["Tech Storytelling", "Video Editing (Premiere/CapCut)", "Technical Documentation", "Personal Branding on X/LinkedIn", "Podcast Production"],
      transitionTips: "Developers who can explain complex tech simply are in immense demand for developer advocacy and content businesses."
    },
    {
      id: "product_management",
      icon: "briefcase",
      category: "management",
      titleKey: "career_pm_title",
      descKey: "career_pm_desc",
      skillsKey: "career_pm_skills",
      demandLevel: "Very High",
      timeToTransition: "4-6 Months",
      avgSalaryGrowth: "+50%",
      primarySkills: ["Agile/Scrum Roadmapping", "User Interviewing", "Jira & Product Analytics", "Business Metrics (ROI, CAC, LTV)", "Cross-functional Leadership"],
      transitionTips: "Senior developers and team leads with good empathy and business acumen are well-positioned for PM roles."
    },
    {
      id: "healthcare_technology",
      icon: "activity",
      category: "domain",
      titleKey: "career_health_title",
      descKey: "career_health_desc",
      skillsKey: "career_health_skills",
      demandLevel: "High",
      timeToTransition: "3-5 Months",
      avgSalaryGrowth: "+40%",
      primarySkills: ["HL7 / FHIR Standards", "Health Informatics", "HIPAA Compliance & Privacy", "Telehealth Platform Ops", "EHR System Integration"],
      transitionTips: "Healthcare is rapidly digitalizing, creating stable, recession-proof tech roles for engineers."
    },
    {
      id: "digital_agriculture",
      icon: "sprout",
      category: "domain",
      titleKey: "career_agri_title",
      descKey: "career_agri_desc",
      skillsKey: "career_agri_skills",
      demandLevel: "Emerging High",
      timeToTransition: "3-5 Months",
      avgSalaryGrowth: "+35%",
      primarySkills: ["IoT Sensors & Telemetry", "Drone Data Analysis", "GIS & Satellite Mapping", "Supply Chain ERP", "Smart Irrigation Automation"],
      transitionTips: "AgriTech is booming worldwide with high government backing and huge social impact."
    },
    {
      id: "freelancing_business",
      icon: "laptop-2",
      category: "business",
      titleKey: "career_freelance_title",
      descKey: "career_freelance_desc",
      skillsKey: "career_freelance_skills",
      demandLevel: "High",
      timeToTransition: "1-3 Months",
      avgSalaryGrowth: "+60%",
      primarySkills: ["Client Acquisition & Pitching", "Full-Stack No-Code / AI Build", "Contracting & Invoicing", "Micro-SaaS Development", "Agency Workflow Automation"],
      transitionTips: "Combine AI workflows with independent consulting to deliver solutions 5x faster directly to global clients."
    }
  ],

  skills: [
    {
      id: "ai_tools",
      icon: "sparkle",
      category: "ai_native",
      titleKey: "skill_ai_title",
      descKey: "skill_ai_desc",
      levelKey: "skill_level_essential",
      keyTools: ["Claude Code", "ChatGPT / GPT-4o", "GitHub Copilot", "Cursor IDE", "Midjourney / V0"],
      importance: 98
    },
    {
      id: "python_lang",
      icon: "code",
      category: "technical",
      titleKey: "skill_py_title",
      descKey: "skill_py_desc",
      levelKey: "skill_level_foundation",
      keyTools: ["Python 3.12+", "FastAPI", "Pandas", "PyTorch / HuggingFace", "LangChain"],
      importance: 92
    },
    {
      id: "cloud_computing",
      icon: "cloud-lightning",
      category: "technical",
      titleKey: "skill_cloud_title",
      descKey: "skill_cloud_desc",
      levelKey: "skill_level_high_demand",
      keyTools: ["AWS / Azure / GCP", "Docker Containers", "Kubernetes", "Serverless Lambda", "Terraform"],
      importance: 90
    },
    {
      id: "cybersecurity_basics",
      icon: "shield-check",
      category: "technical",
      titleKey: "skill_sec_title",
      descKey: "skill_sec_desc",
      levelKey: "skill_level_crucial",
      keyTools: ["Zero Trust Arch", "OWASP Top 10", "Linux Security", "IAM Policies", "Wireshark"],
      importance: 86
    },
    {
      id: "data_analytics",
      icon: "pie-chart",
      category: "technical",
      titleKey: "skill_data_title",
      descKey: "skill_data_desc",
      levelKey: "skill_level_high_demand",
      keyTools: ["PostgreSQL / SQL", "PowerBI / Tableau", "Google BigQuery", "DuckDB", "Excel Advanced"],
      importance: 88
    },
    {
      id: "github_projects",
      icon: "git-pull-request",
      category: "technical",
      titleKey: "skill_git_title",
      descKey: "skill_git_desc",
      levelKey: "skill_level_proof",
      keyTools: ["Git & GitHub Actions", "CI/CD Pipelines", "Portfolio Deployments", "Open Source Collab", "Vercel / Netlify"],
      importance: 89
    },
    {
      id: "communication_skills",
      icon: "messages-square",
      category: "human",
      titleKey: "skill_comm_title",
      descKey: "skill_comm_desc",
      levelKey: "skill_level_human_power",
      keyTools: ["Stakeholder Pitching", "Async Writing", "Active Listening", "Meeting Synthesis", "Product Demos"],
      importance: 95
    },
    {
      id: "problem_solving",
      icon: "brain-circuit",
      category: "human",
      titleKey: "skill_ps_title",
      descKey: "skill_ps_desc",
      levelKey: "skill_level_differentiator",
      keyTools: ["First Principles Thinking", "System Architecture", "Root Cause Analysis (5 Whys)", "Trade-off Evaluation"],
      importance: 96
    },
    {
      id: "creativity_teamwork",
      icon: "users",
      category: "human",
      titleKey: "skill_team_title",
      descKey: "skill_team_desc",
      levelKey: "skill_level_human_power",
      keyTools: ["Design Thinking", "Cross-team Sync", "Empathy-driven UX", "Conflict Resolution", "Agile Retrospectives"],
      importance: 91
    },
    {
      id: "english_communication",
      icon: "globe-2",
      category: "human",
      titleKey: "skill_eng_title",
      descKey: "skill_eng_desc",
      levelKey: "skill_level_global_gate",
      keyTools: ["Professional Emailing", "Technical Documentation", "Global Client Calls", "Prompt Engineering in English"],
      importance: 94
    }
  ],

  quizQuestions: [
    {
      id: "role",
      questionKey: "quiz_q1_text",
      options: [
        { labelKey: "quiz_q1_opt1", value: "routine_tech", score: 1 },
        { labelKey: "quiz_q1_opt2", value: "core_dev", score: 2 },
        { labelKey: "quiz_q1_opt3", value: "infra_data", score: 3 },
        { labelKey: "quiz_q1_opt4", value: "creative_mgmt", score: 3 },
        { labelKey: "quiz_q1_opt5", value: "student_fresher", score: 2 }
      ]
    },
    {
      id: "ai_usage",
      questionKey: "quiz_q2_text",
      options: [
        { labelKey: "quiz_q2_opt1", value: "daily_power", score: 3 },
        { labelKey: "quiz_q2_opt2", value: "occasional", score: 2 },
        { labelKey: "quiz_q2_opt3", value: "rarely_never", score: 1 }
      ]
    },
    {
      id: "skill_level",
      questionKey: "quiz_q3_text",
      options: [
        { labelKey: "quiz_q3_opt1", value: "expert", score: 3 },
        { labelKey: "quiz_q3_opt2", value: "mid", score: 2 },
        { labelKey: "quiz_q3_opt3", value: "beginner", score: 1 }
      ]
    },
    {
      id: "interest",
      questionKey: "quiz_q4_text",
      options: [
        { labelKey: "quiz_q4_opt1", value: "ai_ml" },
        { labelKey: "quiz_q4_opt2", value: "security_cloud" },
        { labelKey: "quiz_q4_opt3", value: "design_product" },
        { labelKey: "quiz_q4_opt4", value: "biz_freelance" }
      ]
    }
  ],

  roadmaps: {
    "30_days": {
      "ai_data": {
        titleKey: "rm_30_ai_title",
        subtitleKey: "rm_30_ai_subtitle",
        steps: [
          { dayKey: "rm_d1_7", titleKey: "rm_30_ai_s1_t", descKey: "rm_30_ai_s1_d" },
          { dayKey: "rm_d8_15", titleKey: "rm_30_ai_s2_t", descKey: "rm_30_ai_s2_d" },
          { dayKey: "rm_d16_22", titleKey: "rm_30_ai_s3_t", descKey: "rm_30_ai_s3_d" },
          { dayKey: "rm_d23_30", titleKey: "rm_30_ai_s4_t", descKey: "rm_30_ai_s4_d" }
        ]
      },
      "cybersecurity": {
        titleKey: "rm_30_sec_title",
        subtitleKey: "rm_30_sec_subtitle",
        steps: [
          { dayKey: "rm_d1_7", titleKey: "rm_30_sec_s1_t", descKey: "rm_30_sec_s1_d" },
          { dayKey: "rm_d8_15", titleKey: "rm_30_sec_s2_t", descKey: "rm_30_sec_s2_d" },
          { dayKey: "rm_d16_22", titleKey: "rm_30_sec_s3_t", descKey: "rm_30_sec_s3_d" },
          { dayKey: "rm_d23_30", titleKey: "rm_30_sec_s4_t", descKey: "rm_30_sec_s4_d" }
        ]
      },
      "cloud": {
        titleKey: "rm_30_cld_title",
        subtitleKey: "rm_30_cld_subtitle",
        steps: [
          { dayKey: "rm_d1_7", titleKey: "rm_30_cld_s1_t", descKey: "rm_30_cld_s1_d" },
          { dayKey: "rm_d8_15", titleKey: "rm_30_cld_s2_t", descKey: "rm_30_cld_s2_d" },
          { dayKey: "rm_d16_22", titleKey: "rm_30_cld_s3_t", descKey: "rm_30_cld_s3_d" },
          { dayKey: "rm_d23_30", titleKey: "rm_30_cld_s4_t", descKey: "rm_30_cld_s4_d" }
        ]
      }
    },
    "90_days": {
      "ai_data": {
        titleKey: "rm_90_ai_title",
        subtitleKey: "rm_90_ai_subtitle",
        steps: [
          { dayKey: "rm_m1", titleKey: "rm_90_ai_s1_t", descKey: "rm_90_ai_s1_d" },
          { dayKey: "rm_m2", titleKey: "rm_90_ai_s2_t", descKey: "rm_90_ai_s2_d" },
          { dayKey: "rm_m3", titleKey: "rm_90_ai_s3_t", descKey: "rm_90_ai_s3_d" }
        ]
      },
      "cybersecurity": {
        titleKey: "rm_90_sec_title",
        subtitleKey: "rm_90_sec_subtitle",
        steps: [
          { dayKey: "rm_m1", titleKey: "rm_90_sec_s1_t", descKey: "rm_90_sec_s1_d" },
          { dayKey: "rm_m2", titleKey: "rm_90_sec_s2_t", descKey: "rm_90_sec_s2_d" },
          { dayKey: "rm_m3", titleKey: "rm_90_sec_s3_t", descKey: "rm_90_sec_s3_d" }
        ]
      },
      "cloud": {
        titleKey: "rm_90_cld_title",
        subtitleKey: "rm_90_cld_subtitle",
        steps: [
          { dayKey: "rm_m1", titleKey: "rm_90_cld_s1_t", descKey: "rm_90_cld_s1_d" },
          { dayKey: "rm_m2", titleKey: "rm_90_cld_s2_t", descKey: "rm_90_cld_s2_d" },
          { dayKey: "rm_m3", titleKey: "rm_90_cld_s3_t", descKey: "rm_90_cld_s3_d" }
        ]
      }
    }
  }
};
